# wiki-site-rgr
University project on ASP.NET MVC

Скрипт для разворачивания базы данных: SQL Create Query.sql
