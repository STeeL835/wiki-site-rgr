﻿using System;

namespace WikiSite.Entities
{
	public class RoleDTO
	{
		public Guid Id { get; set; }
		public string Name { get; set; }
	}
}